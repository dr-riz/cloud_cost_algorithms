import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

public class CostModel {
	// Time converter globals
	final static public double conver_to_hour = 60 * 60;
	final static public double conver_to_month = conver_to_hour * 24 * 30;

	// $0.05 or 5c for network usage (communication) for replication
	final static public double $cost_replication_communication = 0.05;

	// say 10s
	final static public double time_cost_replication_communication = 10;

	// number of I/O request to EBS (assume 1 million, so $0.10
	// Misc cost $0.05
	final static public double constant = 0.10;

	final static public double overloaded = 0.80;

	final static public double hourly_partition_cost = Partition.price
			/ (24.0 /* hours */* 30.0 /* days in a month */);

	final static DecimalFormat df = new DecimalFormat("#.###");

	/**************************************
	 * Cost model using single class queueing networks
	 **************************************/

	public static double calculateCost(Config cnf) {
		boolean verbose = false;

		double vm_cost = 0.0;
		double storage_cost = 0.0;
		double storage_size = 0.0;
		double penalty_cost = 0.0;
		double throughput = 0.0;
		double utilization = 0.0;
		double responseTime = 0.0;

		boolean openModel = TransactionClass.transWL();

		cnf.unstable(false);

		HashMap<Integer, VM> mapvm = cnf.getVMmap();
		Set vms = mapvm.entrySet();
		Iterator vm_iter = vms.iterator();

		while (vm_iter.hasNext()) {
			Map.Entry vmentry = (Map.Entry) vm_iter.next();

			VM vm = (VM) vmentry.getValue();

			// multi-class workload

			boolean delayCenter = false; // its a processing center

			QueuingModel mc = null;
			if (openModel) {
				mc = new MultiClass(vm, cnf, delayCenter, verbose);
			} else {
				mc = new MultiClassClosed(vm, cnf, delayCenter, verbose);
			}

			vm.utilization(mc.utilization());
			vm.responseTime(mc.responseTime());
			vm.throughput(mc.throughput());
			vm.busiestTC(mc.highestUtilTC());

			throughput += mc.throughput();
			utilization += mc.utilization();

			// responseTime += mc.responseTime() * mc.throughput();
			responseTime += mc.responseTime();

			if (mc.utilization() > overloaded) {
				System.out.print("vm (id=" + vm.id() + ", rank="
						+ vm.costRank() + ", rate=" + vm.$cost()
						+ ") has utilization(" + df.format(mc.utilization())
						+ ") > " + overloaded + " with " + vm.numOfClasses()
						+ " classes --- SYSTEM UNSTABLE!\n");
				cnf.unstable(true);
				cnf.cost(-1);
				cnf.responseTime(-1);
				continue;
			}

			/*
			 * not including replication time at this stage "if
			 * (vm.getNumOfReplica() > 0) { responeTime +=
			 * time_cost_replication_communication; } "
			 */

			System.out.print("mlc: ResponseTime of vm (id " + vm.id()
					+ ", type " + vm.type() + ",rank " + vm.costRank()
					+ ", util=" + df.format(mc.utilization()) + ", thruput= "
					+ df.format(mc.throughput()) + ") with" + " TC(");

			Vector<Integer> tcIDs = vm.getAlltc();
			Iterator<Integer> tcid_iter = tcIDs.iterator();
			while (tcid_iter.hasNext()) {
				int tid = tcid_iter.next();
				System.out.print(tid + ",");
			}

			System.out.println(") = " + df.format(mc.responseTime()) + "s, "
					+ "queueLength=" + df.format(mc.queueLength()) + "t");

			// VM Cost
			vm_cost += vm.$cost();

			System.out.println("ideal service_rate (E) = "
					+ df.format(mc.serviceRate() * 60) + "/h");

			// use if calculating storage cost per vm
			storage_cost += calPartitionCostPerVM(vm, cnf);

			// storage sizes: if calculating cost across aggregagated volumes
			// storage_size += calPartitionSizesForVM(vm, cnf);

			// penalties
			penalty_cost += calPenaltyCost(tcIDs, cnf);

			/*
			 * not including partition cost at this stage cost +=
			 * calCommunicationCost(cnf); cost += calPartitionCost(responeTime,
			 * vm.numOfDP(), vm .getNumOfReplica());
			 */
		}

		/*
		 * not including communication cost at this stage cost +=
		 * calCommunicationCost(cnf);
		 */

		// if calculating cost across aggregagated volumes
//		storage_cost = calAggregatePartitionCost(storage_size);
		double config_cost = vm_cost + storage_cost + penalty_cost + constant; // add
		// constant;
		if (cnf.unstable()) {
			return -1;
		} else {
			System.out.println("$cost/h=$" + df.format(config_cost) + "/h");
			// System.out.println("$cost/transaction=$" + df.format(cost) +
			// "/h");

			int numberOfSC = mapvm.size();
			utilization = utilization / ((double) numberOfSC);
			responseTime = responseTime / ((double) numberOfSC);

			cnf.cost(config_cost);
			cnf.vm_cost(vm_cost);
			cnf.storage_cost(storage_cost);
			cnf.penalty_cost(penalty_cost);
			cnf.constant_cost(constant);
			cnf.utilization(utilization);
			cnf.throughput(throughput);
			cnf.responseTime(responseTime);
		}
		return config_cost;
	}

	/**************************************
	 * helper methods for calculating cost
	 **************************************/

	public static double calVMCost(double responseTime, VM vm) {
		long vm_usage_time = roundup(responseTime / conver_to_hour);

		double cost = vm_usage_time * vm.price();
		return cost;
	}

	public static double calPartitionSizesForVM(VM vm, Config conf) {
		HashMap<Integer, Integer> mapdp = vm.getAlldp();
		double aggregated_partition_size = 0;
		if (mapdp != null && mapdp.size() != 0) {
			Set dps = mapdp.entrySet();
			Iterator dp_iter = dps.iterator();

			// copy all ids of all partitions
			while (dp_iter.hasNext()) {
				Map.Entry dpentry = (Map.Entry) dp_iter.next();
				int dp_id = (Integer) dpentry.getKey();
				Partition dp = conf.getdp(dp_id);
				aggregated_partition_size += dp.size();
			}
		}
		aggregated_partition_size = roundup(aggregated_partition_size);
		return aggregated_partition_size;
	}

	public static double calAggregatePartitionCost(
			double aggregated_partition_size) {
		aggregated_partition_size = roundup(aggregated_partition_size);
		double raw_cost = aggregated_partition_size * hourly_partition_cost;
		BigDecimal bd = new BigDecimal(raw_cost).setScale(2, RoundingMode.UP);
		double cent_cost = bd.doubleValue();
		return cent_cost; // calculating cost over aggregated partition size
	}

	public static double calPartitionCostPerVM(VM vm, Config conf) {
		HashMap<Integer, Integer> mapdp = vm.getAlldp();
		double cost = 0;
		if (mapdp != null && mapdp.size() != 0) {
			Set dps = mapdp.entrySet();
			Iterator dp_iter = dps.iterator();

			// copy all ids of all partitions
			while (dp_iter.hasNext()) {
				Map.Entry dpentry = (Map.Entry) dp_iter.next();
				int dp_id = (Integer) dpentry.getKey();
				Partition dp = conf.getdp(dp_id);
				cost += calPartitionCost(dp.size());
			}
		}
		return cost; // calculating partition cost for each vm and then
						// aggregating
	}

	public static double calPenaltyCost(Vector<Integer> tcIDs, Config conf) {
		double cost = 0;
		Iterator<Integer> tcid_iter = tcIDs.iterator();
		while (tcid_iter.hasNext()) {
			int tid = tcid_iter.next();
			TransactionClass tc = conf.gettc(tid);
			double penalty = binaryPenalty(tc);
			if (penalty > 0) {
				System.out.println("SLA violated for TC=" + tc.id()
						+ ", penalty=$" + df.format(penalty));
			}
			cost += penalty;
		}
		return cost;
	}

	public static double binaryPenalty(TransactionClass tc) {
		double penalty = 0;
		if (tc.basepenalty() != -1) {
			double actualResTime = tc.actualResTime();
			double desiredResTime = tc.desiredResTime();
			double diff = actualResTime - desiredResTime;
			if (diff > 0) {
				// commenting below gives us penalty per unit time
				// double tps = tc.getArrivalRate(); // throughput
				// double tph = tps * conver_to_hour;
				// penalty = tc.basepenalty() * tph;
				penalty = tc.basepenalty();
			}
		}
		return penalty;
	}

	public static double calPartitionCost(double storage_used) {
		long roundup_size = roundup(storage_used);

		double cent_cost, raw_cost = roundup_size * hourly_partition_cost;
		BigDecimal bd = new BigDecimal(raw_cost).setScale(2, RoundingMode.UP);
		cent_cost = bd.doubleValue();
		return cent_cost;
	}

	public static double calPartitionCost(double responseTime, Config cnf) {
		int number_of_dps = cnf.numOfDP();
		int num_of_replicas = cnf.numOfReplicas();
		long dp_usage_time = roundup(responseTime / conver_to_month);

		double cost = dp_usage_time * (number_of_dps + num_of_replicas)
				* Partition.price;
		return cost;
	}

	public static double calCommunicationCost(Config cnf) {
		int num_of_replicas = cnf.numOfReplicas();

		double cost = num_of_replicas * $cost_replication_communication;
		return cost;
	}

	/**************************************
	 * helper methods e.g. printing etc.
	 **************************************/

	// Round up to next integer
	public static long roundup(double num) {
		if (num == 0.0) {
			return 0;
		} else {
			double res = Math.ceil(num);
			return (long) res;
		}
	}

}
